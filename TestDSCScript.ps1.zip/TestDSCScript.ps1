Configuration DBServerConfig
{

	Node ("localhost")
	{

		Script TempDir
        	{
	            SetScript = { mkdir C:\temp }
	            TestScript = { test-path "c:\temp" }
	            GetScript = { @{result = (get-content C:\temp) } }
        	}


    }
} 