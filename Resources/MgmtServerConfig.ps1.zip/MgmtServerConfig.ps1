#install-module -name xSQLServer


Configuration MgmtServerConfig
{

    Import-DscResource -ModuleName PSDesiredStateConfiguration    

	Node localhost
 	{

#Install-AzureRMPowershellModules
 		Script Install-AzureRMPowershellModules
        	{
	            SetScript = { 
                    C:\installs\WebpiCmd.exe /Install /Products:WindowsAzurePowershell /AcceptEULA
                 }
	            TestScript = { 
                   $azurepsinstalled=get-wmiobject -class Win32_Product|where-object Name -like '*Azure Powershell*'
            
                    if($Azurepsinstalled)
                    {
                        $True
                    }
                    else
                    {
                        $False
                    }
                }
	            GetScript = {<# This must return a hash table #> }
        	}
<#
        Package AzurePSPackage
        {
            Ensure = "Present"
            Path ="C:\installs\WebpiCmd.exe"
            ProductId = "64C3C1D5-870E-486B-BE4B-181256DC61F4"
            Arguments =  "/Install /Products:'WindowsAzurePowershell' /AcceptEULA"
            Name = "Microsoft Azure PowerShell - October 2015"
        }
        
#>
    }#End of node

}