#install-module -name xSQLServer


Configuration MgmtServerConfig
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds

    )


    Import-DscResource -ModuleName PSDesiredStateConfiguration
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
      

	Node localhost
 	{

#Install-AzureRMPowershellModules
 		Script InstallAzureRMPowershellModules
        	{
	            SetScript = { 
                    $script=C:\installs\WebpiCmd.exe /Install /Products:WindowsAzurePowershell /AcceptEULA /Log:"C:\installs\AzurePSInstalllog.txt"
#                    $script|out-file C:\installs\install.txt
#                    whoami|out-file C:\installs\whoami.txt
                 }
	            TestScript = { 
                   $azurepsinstalled=get-wmiobject -class Win32_Product|where-object Name -like '*Azure Powershell*'
            
                    if($Azurepsinstalled)
                    {
                        $True
                    }
                    else
                    {
                        $False
                    }
                }
	            GetScript = {<# This must return a hash table #> }
                Credential = $DomainCreds
        	}
<#
        Package AzurePSPackage
        {
            Ensure = "Present"
            Path ="C:\installs\WebpiCmd.exe"
            ProductId = "64C3C1D5-870E-486B-BE4B-181256DC61F4"
            Arguments =  "/Install /Products:'WindowsAzurePowershell' /AcceptEULA"
            Name = "Microsoft Azure PowerShell - October 2015"
        }
        
#>
    }#End of node

}