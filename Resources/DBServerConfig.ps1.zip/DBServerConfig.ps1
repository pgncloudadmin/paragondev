Configuration DBServerConfig
{

    Import-DscResource -ModuleName PSDesiredStateConfiguration   

	Node ("localhost")
	{
		#Install Storage Services
		WindowsFeature Storage-Services
		{
			Ensure = "Present"
			Name = "Storage-Services"
		}

		#Install .NET Framework Core
		WindowsFeature NETFrameworkCore
		{
			Ensure = "Present"
			Name = "NET-Framework-Core"
		}
	
		#Install NET-Framework-45-Core
		WindowsFeature NET-Framework-45-Core
		{
			Ensure = "Present"
			Name = "NET-Framework-45-Core"
		}


		#Install Failover-Clustering
		WindowsFeature Failover-Clustering
		{
			Ensure = "Present"
			Name = "Failover-Clustering"
		}

		#Install RDC
		WindowsFeature RDC
		{
			Ensure = "Present"
			Name = "RDC"
		}

		#Install FS-SMB1
		WindowsFeature FS-SMB1
		{
			Ensure = "Present"
			Name = "FS-SMB1"
		}

		#Install Server-Gui-Mgmt-Infra
		WindowsFeature Server-Gui-Mgmt-Infra
		{
			Ensure = "Present"
			Name = "Server-Gui-Mgmt-Infra"
		}

		#Install Server-Gui-Shell
		WindowsFeature Server-Gui-Shell
		{
			Ensure = "Present"
			Name = "Server-Gui-Shell"
		}
<#
		#Had an issue with this returning an error, even though PS is installed OOB
		#Install  PowerShell
		WindowsFeature  PowerShell
		{
			Ensure = "Present"
			Name = " PowerShell"
		}
#>
		#Install PowerShell-V2
		WindowsFeature PowerShell-V2
		{
			Ensure = "Present"
			Name = "PowerShell-V2"
		}

		#Install PowerShell-ISE
		WindowsFeature PowerShell-ISE
		{
			Ensure = "Present"
			Name = "PowerShell-ISE"
		}
		
		#Install WoW64-Support
		WindowsFeature WoW64-Support
		{
			Ensure = "Present"
			Name = "WoW64-Support"
		}

		#Install XPS-Viewer
		WindowsFeature XPS-Viewer
		{
			Ensure = "Present"
			Name = "XPS-Viewer"
		}


		#Install NET-WCF-TCP-PortSharing45
		WindowsFeature NET-WCF-TCP-PortSharing45


		{
			Ensure = "Present"
			Name = "NET-WCF-TCP-PortSharing45"
		}

		Script Set-ParagonPowerPlan
        	{
	            SetScript = { Powercfg -SETACTIVE SCHEME_MIN }
	            TestScript = { return ( Powercfg -getactivescheme) -like "*High Performance*" }
	            GetScript = { return @{ Powercfg = ( "{0}" -f ( powercfg -getactivescheme ) ) } }
        	}

		Script Configure-StoragePool
        	{
	            SetScript = { 
		        $PhysicalDisks = Get-StorageSubSystem -FriendlyName "Storage Spaces*" | Get-PhysicalDisk -CanPool $True
                $DataDisks = $PhysicalDisks | Where-Object FriendlyName -in('PhysicalDisk2','PhysicalDisk3','Physicaldisk4','PhysicalDisk5')
                $LogDisks = $PhysicalDisks | Where-Object FriendlyName -in('PhysicalDisk6','PhysicalDisk7')
                $SystemDisks = $PhysicalDisks | Where-Object FriendlyName -in('PhysicalDisk8','PhysicalDisk9')

		        If($DataDisks.Count -gt 3)
			    {
			        $totalstorageconfigresult = New-StoragePool -FriendlyName "SQLData1Pool01A" -StorageSubsystemFriendlyName "Storage Spaces*" -PhysicalDisks $DataDisks | New-VirtualDisk -FriendlyName "SQLData1Disk01A" -Size 4088GB -ProvisioningType Fixed -ResiliencySettingName Simple|Initialize-Disk -PassThru | New-Partition -DriveLetter 'F' -UseMaximumSize
			        write-output $totalstorageconfigresult
                    start-sleep -s 30
			        $Partition = get-partition| Where-Object DriveLetter -eq "F" 
				
                    if ($Partition)
	   			    {
					    $formatvolumeresult = $Partition|Format-Volume -Confirm:$False -AllocationUnitSize 64KB
                        write-output $formatvolumeresult
				    }
			    }
			    else
		        {
           		    Write-Output "$(get-date) : All 4 data disks are not available. Please review to confirm disks were created successfully. Details of disks are below"
           		    Write-Error($DataDisks) -ErrorAction Stop
           		}
	
                If($LogDisks.Count -gt 1)
			    {
			        $totalstorageconfigresult2 = New-StoragePool -FriendlyName "SQLLogsPool01A" -StorageSubsystemFriendlyName "Storage Spaces*" -PhysicalDisks $LogDisks | New-VirtualDisk -FriendlyName "SQLLogs1Disk01A" -Size 2044GB -ProvisioningType Fixed -ResiliencySettingName Simple|Initialize-Disk -PassThru | New-Partition -DriveLetter 'G' -UseMaximumSize
			        write-output $totalstorageconfigresult2
                    start-sleep -s 30
			        $Partition = get-partition| Where-Object DriveLetter -eq "G" 
				    if ($Partition)
 				    {
					    $formatvolumeresult2 = $Partition|Format-Volume -Confirm:$False -AllocationUnitSize 64KB
                        write-output $formatvolumeresult2
  				    }
			    }
			    else
		        {
           		Write-Output "$(get-date) : Two log disks are not available. Please review to confirm disk are created successfully. Details of disks are below"
           		Write-Error($PhysicalDisks) -ErrorAction Stop
           		}
           			
		        If($SystemDisks.Count -gt 1)
			    {
                    $totalstorageconfigresult3 = New-StoragePool -FriendlyName "SQLSystemDBPool01A" -StorageSubsystemFriendlyName "Storage Spaces*" -PhysicalDisks $SystemDisks | New-VirtualDisk -FriendlyName "SQLSystemDBDisk01A" -Size 2044GB -ProvisioningType Fixed -ResiliencySettingName Simple|Initialize-Disk -PassThru | New-Partition -DriveLetter 'H' -UseMaximumSize
			      	write-output $totalstorageconfigresult3
                    start-sleep -s 30
			        $Partition = get-partition| Where-Object DriveLetter -eq "H" 
				    if ($Partition)
 				    {
					    $formatvolumeresult2 = $Partition|Format-Volume -Confirm:$False -AllocationUnitSize 64KB
                        write-output $formatvolumeresult2
  				    }
			    }
			    else
		        {
           		Write-Output "$(get-date) : Two system disks are not available. Please review to confirm disk are created successfully. Details of disks are below"
           		Write-Error($SystemDisks) -ErrorAction Stop
           		}

		    } #End of Set script for ConfigureStoragePool
	            TestScript = { 
                    $Storagepools=get-storagepool |Where-object friendlyname -in ('SQLData1Pool01A','SQLLogsPool01A','SQLSystemDBPool01A')
                    if($StoragePools.count -eq 3)
                    {
                        $True
                    }
                    else
                    {
                        $False
                    }
                } #End of Test Script
	            GetScript = { <# This must return a hash table #> } 
        	} #End of ConfigureStoragePool 

		Script Configure-MountPoints
        	{
	            SetScript = { 

                #Configure MountPoint
    	        $DataPath ='C:\DataRoot\Data1'
		        $LogPath ='C:\DataRoot\Logs'
		        $SystemDBPath = 'C:\DataRoot\SystemDB'
		        Write-Output ("$(get-date) : Set-AzureParagonNthDBStorageConfiguration: Configuring Mount Point Folder Structure")
		        #Create directories for Data, Log, System DB
		        if (!(Test-path $DataPath))
		        {
    		        $datapathfoldercreateresult = New-Item $DataPath -type Directory
                    write-output $datapathfoldercreateresult
		        }
		        if (!(Test-path $LogPath))
		        {
    		        $logpathfoldercreateresult = New-Item $LogPath -type Directory
                    write-output $logpathfoldercreateresult
		        }
		        if (!(Test-path $SystemDBPath))
		        {
    		        $systemdbpathfoldercreateresult = New-Item $SystemDBPath -type Directory
                    write-output $systemdbpathfoldercreateresult
		        }
		        Write-Output ("$(get-date) : Set-AzureParagonNthDBStorageConfiguration: Mount Point directories created.")		
		
		        #Mount volumes to access path directories
		        $fdrive=get-partition -DriveLetter f
                $datampdrive=$fdrive|where-object AccessPaths -like "$DataPath\"
                if($datampdrive -eq $Null)
                {
    		        $partitiondatapathresult = Get-Partition -DriveLetter F |Add-PartitionAccessPath -PartitionNumber 2 -AccessPath $DataPath
                    write-output $partitiondatapathresult
                }
                $gdrive=get-partition -DriveLetter g
                $logmpdrive=$gdrive|where-object AccessPaths -like "$LogPath\"
                if($Logmpdrive -eq $Null)
                {
    		        $partitionlogpathresult = Get-Partition -DriveLetter G |Add-PartitionAccessPath -PartitionNumber 2 -AccessPath $LogPath
                    write-output $partitionlogpathresult
                }
                $hdrive=get-partition -DriveLetter h
                $systemdbmpdrive=$hdrive|where-object AccessPaths -like "$SystemDBPath\"
                if($systemdbmpdrive -eq $Null)
                {
	    	        $partitionsystpathresult = Get-Partition -DriveLetter H |Add-PartitionAccessPath -PartitionNumber 2 -AccessPath $SystemDBPath
                    write-output $partitionsystpathresult
                }
		        Write-Output ("$(get-date) : Set-AzureParagonNthDBStorageConfiguration: Partitions mounted to mount point directories.")		
                }
	            TestScript = {

                $fdrive=get-partition -DriveLetter f
                $gdrive=get-partition -DriveLetter g
                $hdrive=get-partition -DriveLetter h

                $datampdrive=$fdrive|where-object AccessPaths -eq 'C:\DataRoot\Data1\'
                $logmpdrive=$gdrive|where-object AccessPaths -eq 'C:\DataRoot\logs\'
                $systemmpdrive=$hdrive|where-object AccessPaths -eq 'C:\DataRoot\systemDB\'

                    if($datampdrive -ne $Null -and $logmpdrive -ne $null -and $systemmpdrive -ne $null)
                    {
                        $true
                    }
                    else
                    {
                        $False
                    }
                 }#End of TestScript 
	            GetScript = {<# This must return a hash table #> }
                DependsOn = "[Script]Configure-StoragePool"
        	}#End of script ConfigureMountPoints

#Set-ParagonMSDTCConfig
        #SET-ITEMPROPERTY HKLM:\software\microsoft\ole -name "EnableDCOM" -value "Y" -ErrorAction Stop
        Registry EnableDCOM
        {
            Ensure = "Present"
            Key = "HKLM:\software\microsoft\ole"
            ValueName = "EnableDCOM"
            ValueData = "Y"
        }
        #SET-ITEMPROPERTY HKLM:\software\microsoft\ole -name "LegacyImpersonationLevel" -value 2 -type "Dword" -ErrorAction SilentlyContinue
        Registry LegacyImpersonationLevel
        {
            Ensure = "Present"
            Key = "HKLM:\software\microsoft\ole"
            ValueName = "LegacyImpersonationLevel"
            ValueData = "Y"
            ValueType ="Dword"
        }
 
        #SET-ITEMPROPERTY HKLM:\software\microsoft\ole -name "LegacyAuthenticationLevel" -value 2 -type "Dword" -ErrorAction SilentlyContinue
        Registry LegacyAuthenticationLevel
        {
            Ensure = "Present"
            Key = "HKLM:\software\microsoft\ole"
            ValueName = "LegacyAuthenticationLevel"
            ValueData = "Y"
            ValueType ="Dword"
        }
        
        #SET-ITEMPROPERTY HKLM:\software\microsoft\ole -name "MachineLaunchRestriction" `
        #            -value ([byte[]](0x01,0x00,0x04,0x80,0x90,0x00,0x00,0x00,0xa0,0x00,0x00,0x00,0x00, `
        #            0x00,0x00,0x00,0x14,0x00,0x00,0x00,0x02,0x00,0x7c,0x00,0x05,0x00,0x00,0x00,0x00, `
        #            0x00,0x14,0x00,0x1f,0x00,0x00,0x00,0x01,0x01,0x00,0x00,0x00,0x00,0x00,0x01,0x00, `
        #            0x00,0x00,0x00,0x00,0x00,0x18,0x00,0x0b,0x00,0x00,0x00,0x01,0x02,0x00,0x00,0x00, `
        #            0x00,0x00,0x0f,0x02,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x18,0x00,0x1f, `
        #            0x00,0x00,0x00,0x01,0x02,0x00,0x00,0x00,0x00,0x00,0x05,0x20,0x00,0x00,0x00,0x20, `
        #            0x02,0x00,0x00,0x00,0x00,0x18,0x00,0x1f,0x00,0x00,0x00,0x01,0x02,0x00,0x00,0x00, `
        #            0x00,0x00,0x05,0x20,0x00,0x00,0x00,0x2f,0x02,0x00,0x00,0x00,0x00,0x18,0x00,0x1f, `
        #            0x00,0x00,0x00,0x01,0x02,0x00,0x00,0x00,0x00,0x00,0x05,0x20,0x00,0x00,0x00,0x32, `
        #            0x02,0x00,0x00,0x01,0x02,0x00,0x00,0x00,0x00,0x00,0x05,0x20,0x00,0x00,0x00,0x20, `
        #            0x02,0x00,0x00,0x01,0x02,0x00,0x00,0x00,0x00,0x00,0x05,0x20,0x00,0x00,0x00,0x20, `
        #            0x02,0x00,0x00)) -ErrorAction Stop
<#   
        Registry MachineLaunchRestriction
        {
            Ensure = "Present"
            Key = "HKLM:\software\microsoft\ole"
            ValueName = "MachineLaunchRestriction"
            ValueData = $value
        }
#>


        #SET-ITEMPROPERTY HKLM:\software\microsoft\MSDTC\security -name "networkdtcaccess" -value "1" -ErrorAction Stop
        Registry networkdtcaccess
        {
            Ensure = "Present"
            Key = "HKLM:\software\microsoft\MSDTC\security"
            ValueName = "networkdtcaccess"
            ValueData = "1"
        }

        #SET-ITEMPROPERTY HKLM:\software\microsoft\MSDTC\security -name "networkdtcaccessadmin" -value "1" -ErrorAction Stop
        Registry networkdtcaccessadmin
        {
            Ensure = "Present"
            Key = "HKLM:\software\microsoft\MSDTC\security"
            ValueName = "networkdtcaccessadmin"
            ValueData = "1"
        }
        
        #SET-ITEMPROPERTY HKLM:\software\microsoft\MSDTC\security -name "networkdtcaccessinbound" -value "1" -ErrorAction Stop
        Registry networkdtcaccessinbound
        {
            Ensure = "Present"
            Key = "HKLM:\software\microsoft\MSDTC\security"
            ValueName = "networkdtcaccessinbound"
            ValueData = "1"
        }
        
        #SET-ITEMPROPERTY HKLM:\software\microsoft\MSDTC\security -name "networkdtcaccessoutbound" -value "1" -ErrorAction Stop
        Registry networkdtcaccessoutbound
        {
            Ensure = "Present"
            Key = "HKLM:\software\microsoft\MSDTC\security"
            ValueName = "networkdtcaccessoutbound"
            ValueData = "1"
        }

        #SET-ITEMPROPERTY HKLM:\software\microsoft\MSDTC\security -name "networkdtcaccesstransactions" -value "1" -ErrorAction Stop
        Registry networkdtcaccesstransactions
        {
            Ensure = "Present"
            Key = "HKLM:\software\microsoft\MSDTC\security"
            ValueName = "networkdtcaccesstransactions"
            ValueData = "1"
        }	        

        #SET-ITEMPROPERTY HKLM:\software\microsoft\MSDTC\security -name "XAtransactions" -value "1" -ErrorAction Stop
        Registry XAtransactions
        {
            Ensure = "Present"
            Key = "HKLM:\software\microsoft\MSDTC\security"
            ValueName = "XAtransactions"
            ValueData = "1"
        }	        

        #SET-ITEMPROPERTY HKLM:\software\microsoft\MSDTC\security -name "LuTransactions" -value "1" -ErrorAction Stop
        Registry LuTransactions
        {
            Ensure = "Present"
            Key = "HKLM:\software\microsoft\MSDTC\security"
            ValueName = "LuTransactions"
            ValueData = "1"
        }	        

        #SET-ITEMPROPERTY HKLM:\software\microsoft\MSDTC -name "turnoffrpcsecurity" -value "1" -ErrorAction Stop
        Registry turnoffrpcsecurity
        {
            Ensure = "Present"
            Key = "HKLM:\software\microsoft\MSDTC\security"
            ValueName = "turnoffrpcsecurity"
            ValueData = "1"
        }	        

        #SET-ITEMPROPERTY HKLM:\software\microsoft\MSDTC -name "AllowonlySecureRPCCalls" -value "0" -ErrorAction Stop
        Registry AllowonlySecureRPCCalls
        {
            Ensure = "Present"
            Key = "HKLM:\software\microsoft\MSDTC\security"
            ValueName = "AllowonlySecureRPCCalls"
            ValueData = "1"
        }

   		Script Restart-MSDTCService
       	{
            SetScript = { Start-Sleep	-seconds 30 RESTART-SERVICE "MSDTC" }
            TestScript = { $False }
            GetScript = { <# This must return a hash table #> }
       	}
#Set-ParagonTSConfig
        #SET-ITEMPROPERTY -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -name "fAutoClientDrives" -Value 1 -ErrorAction Stop
        Registry AllowonlySecureRPCCalls
        {
            Ensure = "Present"
            Key = "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
            ValueName = "fAutoClientDrives"
            ValueData = "1"
        }

        #SET-ITEMPROPERTY -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -name "fAutoClientLpts" -Value 1 -ErrorAction Stop
        Registry fAutoClientLpts
        {
            Ensure = "Present"
            Key = "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
            ValueName = "fAutoClientLpts"
            ValueData = "1"
        }

        #SET-ITEMPROPERTY -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -name "fDisableAudioCapture" -Value 1 -ErrorAction Stop
        {
            Ensure = "Present"
            Key = "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
            ValueName = "fDisableAudioCapture"
            ValueData = "1"
        }

        #SET-ITEMPROPERTY -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -name "fDisableCam" -Value 1 -ErrorAction Stop
        {
            Ensure = "Present"
            Key = "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
            ValueName = "fDisableCam"
            ValueData = "1"
        }

        #SET-ITEMPROPERTY -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -name "fDisableCcm" -Value 1 -ErrorAction Stop
        {
            Ensure = "Present"
            Key = "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
            ValueName = "fDisableCcm"
            ValueData = "1"
        }

        #SET-ITEMPROPERTY -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -name "fDisableCdm" -Value 0 -ErrorAction Stop
        {
            Ensure = "Present"
            Key = "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
            ValueName = "fDisableCdm"
            ValueData = "0"
        }

        #SET-ITEMPROPERTY -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -name "fDisableCpm" -Value 1 -ErrorAction Stop
        {
            Ensure = "Present"
            Key = "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
            ValueName = "fDisableCpm"
            ValueData = "1"
        }

        #SET-ITEMPROPERTY -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' -name "fDisableLPT" -Value 1 -ErrorAction Stop
        {
            Ensure = "Present"
            Key = "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
            ValueName = "fDisableLPT"
            ValueData = "1"
        }
        #SET-ITEMPROPERTY -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -name "fsinglesessionperuser" -value 0 -ErrorAction Stop
        {
            Ensure = "Present"
            Key = "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
            ValueName = "fsinglesessionperuser"
            ValueData = "0"
        }


#Set-ParagonDisallowAnimations
        #SET-ITEMPROPERTY -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DWM' -name "DisallowAnimations" -Value 1 -ErrorAction Stop
        {
            Ensure = "Present"
            Key = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DWM"
            ValueName = "DisallowAnimations"
            ValueData = "1"
        }
#New-ParagonDataCollectorSet
#Need to review this one, as it will not have SQL installed initially which is required to determine instance names for DCS
    }
} 