Configuration DBServerConfig
{

    Import-DscResource -ModuleName PSDesiredStateConfiguration   

	Node ("localhost")
	{
		#Install Storage Services
		WindowsFeature Storage-Services
		{
			Ensure = "Present"
			Name = "Storage-Services"
		}

		#Install .NET Framework Core
		WindowsFeature NETFrameworkCore
		{
			Ensure = "Present"
			Name = "NET-Framework-Core"
		}
	
		#Install NET-Framework-45-Core
		WindowsFeature NET-Framework-45-Core
		{
			Ensure = "Present"
			Name = "NET-Framework-45-Core"
		}


		#Install Failover-Clustering
		WindowsFeature Failover-Clustering
		{
			Ensure = "Present"
			Name = "Failover-Clustering"
		}

		#Install RDC
		WindowsFeature RDC
		{
			Ensure = "Present"
			Name = "RDC"
		}

		#Install FS-SMB1
		WindowsFeature FS-SMB1
		{
			Ensure = "Present"
			Name = "FS-SMB1"
		}

		#Install Server-Gui-Mgmt-Infra
		WindowsFeature Server-Gui-Mgmt-Infra
		{
			Ensure = "Present"
			Name = "Server-Gui-Mgmt-Infra"
		}

		#Install Server-Gui-Shell
		WindowsFeature Server-Gui-Shell
		{
			Ensure = "Present"
			Name = "Server-Gui-Shell"
		}

		#Install  PowerShell
		WindowsFeature  PowerShell
		{
			Ensure = "Present"
			Name = " PowerShell"
		}

		#Install PowerShell-V2
		WindowsFeature PowerShell-V2
		{
			Ensure = "Present"
			Name = "PowerShell-V2"
		}

		#Install PowerShell-ISE
		WindowsFeature PowerShell-ISE
		{
			Ensure = "Present"
			Name = "PowerShell-ISE"
		}
		
		#Install WoW64-Support
		WindowsFeature WoW64-Support
		{
			Ensure = "Present"
			Name = "WoW64-Support"
		}

		#Install XPS-Viewer
		WindowsFeature XPS-Viewer
		{
			Ensure = "Present"
			Name = "XPS-Viewer"
		}


		#Install NET-WCF-TCP-PortSharing45
		WindowsFeature NET-WCF-TCP-PortSharing45


		{
			Ensure = "Present"
			Name = "NET-WCF-TCP-PortSharing45"
		}
		#Install Powershell DSC
		WindowsFeature DSC-Service
		{
			Ensure = "Present"
			Name = "DSC-Service"
		}

		Script PowerPlan
        	{
	            SetScript = { Powercfg -SETACTIVE SCHEME_MIN }
	            TestScript = { return ( Powercfg -getactivescheme) -like "*High Performance*" }
	            GetScript = { return @{ Powercfg = ( "{0}" -f ( powercfg -getactivescheme ) ) } }
        	}


    }
} 